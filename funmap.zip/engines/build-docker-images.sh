#!/bin/bash


cd rmlmapper
docker build -t rmlmapper .
cd ../sdmrdfizer
docker build -t sdmrdfizer .
cd ../rocketrml
docker build -t rocketrml .
cd ../fun_map
docker build -t funmap .
cd ../fun_map_baseline
docker build -t funmap_baseline .