
----- Welcome to FunMap Engine ------

Requirements: Intall docker and docker-compose in your Linux machine

To run the engines:
1) Go to engines folder and run in a terminal: bash build-docker-images.sh
2) Run: docker-compose up -d
3) Docker images of all engines are running and data and mappings shared with all of them, ready to run the experiments. Each engine has a README inside its folder with an explanaition on how to run it.


Bugs folder: RocketRML do not execute correctly joins with multiple conditions. In order to demonstrate it we provide a simple example with the expected output and the actually RocketRML output containing a set of duplicate triples.




