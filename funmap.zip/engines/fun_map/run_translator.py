from translator.translate import translate
import sys
translate(str(sys.argv[1]))