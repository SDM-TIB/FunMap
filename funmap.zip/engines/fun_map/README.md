# To run the engine

python3 run_translator.py config.ini
